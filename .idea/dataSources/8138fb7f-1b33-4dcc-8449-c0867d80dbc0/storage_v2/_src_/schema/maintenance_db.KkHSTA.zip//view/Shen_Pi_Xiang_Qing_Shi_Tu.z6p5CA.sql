create definer = root@localhost view 审批详情视图 as
select `maintenance_db`.`user_info`.`username`            AS `username`,
       `maintenance_db`.`approval_info`.`manip_time`      AS `manip_time`,
       `maintenance_db`.`approval_info`.`approval_remark` AS `approval_remark`,
       `maintenance_db`.`approval_info`.`step_order`      AS `step_order`,
       `maintenance_db`.`equip_info`.`equip_name`         AS `equip_name`,
       `maintenance_db`.`maintance_info`.`maintance_desc` AS `maintance_desc`,
       `maintenance_db`.`maintance_info`.`start_time`     AS `start_time`,
       `maintenance_db`.`maintance_info`.`end_time`       AS `end_time`,
       `maintenance_db`.`maintance_info`.`status`         AS `status`,
       `maintenance_db`.`approval_info`.`approval_status` AS `approval_status`
from (((`maintenance_db`.`approval_info` join `maintenance_db`.`maintance_info`
        on ((`maintenance_db`.`approval_info`.`plan_id` =
             `maintenance_db`.`maintance_info`.`plan_id`))) left join `maintenance_db`.`user_info`
       on ((`maintenance_db`.`approval_info`.`applicant_id` =
            `maintenance_db`.`user_info`.`user_id`))) join `maintenance_db`.`equip_info`
      on ((`maintenance_db`.`maintance_info`.`equip_id` = `maintenance_db`.`equip_info`.`equip_id`)))
where (`maintenance_db`.`maintance_info`.`plan_id` = '1839912235471466497')
order by `maintenance_db`.`approval_info`.`step_order`;

