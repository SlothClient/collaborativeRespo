create definer = root@localhost view order_summary as
select `o`.`order_id`     AS `order_id`,
       `o`.`equip_id`     AS `equip_id`,
       `o`.`plan_id`      AS `plan_id`,
       `o`.`start_time`   AS `start_time`,
       `o`.`end_time`     AS `end_time`,
       `o`.`worker_id`    AS `worker_id`,
       `o`.`order_desc`   AS `order_desc`,
       `o`.`order_record` AS `order_record`,
       `o`.`order_status` AS `order_status`,
       `o`.`check_id`     AS `check_id`,
       `m`.`plan_name`    AS `plan_name`,
       `m`.`end_time`     AS `planTime`,
       `w`.`worker_name`  AS `worker_name`
from ((`maintenance_db`.`order_info` `o` join `maintenance_db`.`maintance_info` `m`
       on ((`o`.`plan_id` = `m`.`plan_id`))) join `maintenance_db`.`worker_info` `w`
      on ((`o`.`worker_id` = `w`.`worker_id`)));

