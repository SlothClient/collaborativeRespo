create definer = root@localhost view selected_equip_summary as
select `eq`.`equip_name`     AS `equip_name`,
       `eq`.`equip_id`       AS `equip_id`,
       `eq`.`equip_pic`      AS `equip_pic`,
       `eq`.`last_maintance` AS `last_maintance`,
       `mt`.`maintance_desc` AS `maintance_desc`,
       `od`.`order_desc`     AS `order_desc`,
       `od`.`order_record`   AS `order_record`,
       `mt`.`plan_id`        AS `plan_id`
from ((`maintenance_db`.`equip_info` `eq` join `maintenance_db`.`maintance_info` `mt`
       on ((`eq`.`equip_id` = `mt`.`equip_id`))) join `maintenance_db`.`order_info` `od`
      on ((`mt`.`plan_id` = `od`.`plan_id`)));

