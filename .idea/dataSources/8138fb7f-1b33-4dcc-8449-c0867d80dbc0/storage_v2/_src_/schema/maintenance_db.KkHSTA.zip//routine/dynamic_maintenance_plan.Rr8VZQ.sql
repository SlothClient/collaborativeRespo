create
    definer = root@localhost procedure dynamic_maintenance_plan()
BEGIN
    -- 标识是否结束循环
    DECLARE DONE INT DEFAULT 0;

    -- 维护周期变量
    DECLARE maintenance_cycle TINYINT;
    DECLARE maintenance_type_name VARCHAR(30);
    
    -- 设备信息变量
    DECLARE equip_id VARCHAR(30);
    DECLARE fix_big TINYINT;
    DECLARE fix_medium TINYINT;
    DECLARE fix_small TINYINT;
    DECLARE purchase_date DATETIME;
    DECLARE equip_name VARCHAR(30);

    -- 定义保养计划ID和审批ID的变量
    DECLARE plan_id VARCHAR(30);
    DECLARE applicant_approval_id VARCHAR(30);
    DECLARE first_approval_id VARCHAR(30);
    DECLARE second_approval_id VARCHAR(30);

    
		
		 -- 定义游标
    DECLARE cur CURSOR FOR 
    SELECT equip_id, fix_big, fix_medium, fix_small, purchase_date, equip_name FROM equip_info;

		DECLARE CONTINUE HANDLER FOR NOT FOUND SET DONE = 1;
		
    -- 打开游标
    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO equip_id, fix_big, fix_medium, fix_small, purchase_date, equip_name;

        IF DONE THEN 
            LEAVE read_loop; 
        END IF;

        -- 初始化维护周期
        SET maintenance_cycle = 0;
				
        IF DATEDIFF(CURRENT_DATE(), purchase_date) % fix_big = 0 THEN -- 大修
            SET maintenance_cycle = fix_big;
            SET maintenance_type_name = '大修周期';
						
        ELSEIF DATEDIFF(CURRENT_DATE(), purchase_date) % fix_medium = 0 THEN -- 中修
            SET maintenance_cycle = fix_medium;
            SET maintenance_type_name = '中修周期';
						
        ELSEIF DATEDIFF(CURRENT_DATE(), purchase_date) % fix_small = 0 THEN -- 小修
            SET maintenance_cycle = fix_small;
            SET maintenance_type_name = '小修周期';
						
        END IF;

        IF maintenance_cycle != 0 THEN
            -- 生成新插入的保养计划ID
            SET plan_id = UUID();

            -- 插入保养计划
            INSERT INTO maintance_info (plan_id, equip_id, maintance_desc, maintance_type, plan_name, start_time, end_time, status)
            VALUES (plan_id, equip_id, CONCAT('定期维护-', maintenance_type_name), maintenance_type_name, CONCAT('保养计划-', equip_name, '-', maintenance_cycle), CURRENT_DATE(), DATE_ADD(CURRENT_DATE(), INTERVAL 7 DAY), 0);

            -- 生成审批ID
            SET applicant_approval_id = UUID();
            SET first_approval_id = UUID();
            SET second_approval_id = UUID();

            -- 插入申请人审批记录 默认为U003，状态设置为已申请（2）
            INSERT INTO approval_info (approval_id, plan_id, applicant_id, approval_status, step_order, manip_time)
            VALUES (applicant_approval_id, plan_id, 'U003', 2, 0, CURRENT_TIMESTAMP());

            -- 插入一级审批记录（待审批状态）
            INSERT INTO approval_info (approval_id, plan_id, approval_status, step_order, father_id)
            VALUES (first_approval_id, plan_id, 0, 1, applicant_approval_id);

            -- 插入二级审批记录（待审批状态）
            INSERT INTO approval_info (approval_id, plan_id, approval_status, step_order, father_id)
            VALUES (second_approval_id, plan_id, 0, 2, first_approval_id);
        END IF;
    END LOOP;

    -- 关闭游标
    CLOSE cur;
END;

