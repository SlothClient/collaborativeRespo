create definer = ``@`` view 审批详情视图 as
select `maintancedb`.`user_info`.`username`            AS `username`,
       `maintancedb`.`approval_info`.`manip_time`      AS `manip_time`,
       `maintancedb`.`approval_info`.`approval_remark` AS `approval_remark`,
       `maintancedb`.`approval_info`.`step_order`      AS `step_order`,
       `maintancedb`.`equip_info`.`equip_name`         AS `equip_name`,
       `maintancedb`.`maintance_info`.`maintance_desc` AS `maintance_desc`,
       `maintancedb`.`maintance_info`.`start_time`     AS `start_time`,
       `maintancedb`.`maintance_info`.`end_time`       AS `end_time`,
       `maintancedb`.`maintance_info`.`status`         AS `status`,
       `maintancedb`.`approval_info`.`approval_status` AS `approval_status`
from (((`maintancedb`.`approval_info` join `maintancedb`.`maintance_info` on ((`maintancedb`.`approval_info`.`plan_id` =
                                                                               `maintancedb`.`maintance_info`.`plan_id`))) left join `maintancedb`.`user_info`
       on ((`maintancedb`.`approval_info`.`applicant_id` =
            `maintancedb`.`user_info`.`user_id`))) join `maintancedb`.`equip_info`
      on ((`maintancedb`.`maintance_info`.`equip_id` = `maintancedb`.`equip_info`.`equip_id`)))
where (`maintancedb`.`maintance_info`.`plan_id` = '1839912235471466497')
order by `maintancedb`.`approval_info`.`step_order`;

